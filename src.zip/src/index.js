const { ApolloServer, gql } = require('apollo-server');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const typeDefs = gql`
  type Session {
    id: String!
    shop: String!
    state: String!
    isOnline: Boolean!
    scope: String
    expires: String
    accessToken: String!
    userId: Int
  }

  type User {
    id: Int!
    email: String!
    name: String
    articles: [Article]
  }

  type Article {
    id: Int!
    title: String!
    body: String
    author: User!
  }

  type Query {
    users: [User]
    user(id: Int!): User
    articles: [Article]
  }

  type Mutation {
    createUser(name: String, email: String!): User
    updateUser(id: Int!, name: String): User
    deleteUser(id: Int!): User
    createArticle(title: String!, body: String, authorId: Int!): Article
  }
`;

const resolvers = {
  Query: {
    users: async () => prisma.users.findMany(),
    user: async (_, { id }) => prisma.users.findUnique({ where: { id } }),
    articles: async () => prisma.articles.findMany(),
  },
  Mutation: {
    createUser: async (_, { name, email }) => prisma.users.create({ data: { name, email } }),
    updateUser: async (_, { id, name }) => prisma.users.update({ where: { id }, data: { name } }),
    deleteUser: async (_, { id }) => prisma.users.delete({ where: { id } }),
    createArticle: async (_, { title, body, authorId }) =>
      prisma.articles.create({ data: { title, body, authorId } }),
  },
  User: {
    articles: async (parent) => prisma.articles.findMany({ where: { authorId: parent.id } }),
  },
  Article: {
    author: async (parent) => prisma.users.findUnique({ where: { id: parent.authorId } }),
  },
};

const server = new ApolloServer({ typeDefs, resolvers });

server.listen().then(({ url }) => {
  console.log(`Server running at ${url}`);
});
